<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Attribute extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'display_type', 'has_image', 'status'];

    public function items()
    {
        return $this->hasMany(AttributeItem::class, 'attribute_id');
    }
}
